import matplotlib.pyplot as plt
import nltk
from nltk import pos_tag, WordNetLemmatizer, FreqDist
from nltk.tokenize import WordPunctTokenizer

# 打开并读取文件
file = open('The Project Gutenberg Etext of Moby Dick, by Herman Melville.txt', 'r', encoding='utf-8')

content = file.read()

# 下面进行分词处理
tokenizer = WordPunctTokenizer()
tokens = tokenizer.tokenize(content)

file.close()

# 将tokens输入到Tokens文件夹中
file = open('Tokens.txt', 'w', encoding='utf-8')
file.writelines('\n'.join(tokens))
file.close()

# 接下来去除停用词
stopwords = ['the', 'a', 'an', 'is', 'in', 'it', 'of']

file = open('Tokens.txt', 'r', encoding='utf-8')
tokens = file.read().splitlines()

# 过滤停用词
filtered_tokens = []
for token in tokens:
    if token.lower() not in stopwords:
        filtered_tokens.append(token)

file.close()

file = open('filter.txt', 'w', encoding='utf-8')
file.writelines('\n'.join(filtered_tokens))

file.close()

# 接下来进行tag词性分析
file = open('filter.txt', 'r', encoding='utf-8')
tokens = file.read().splitlines()

tag = pos_tag(tokens)

file.close()

file = open('tag.txt', 'w', encoding='utf-8')
file.writelines(f'{token}\t{tag}\n' for token, tag in tag)
file.close()

# 接下来对tag出现频率进行分析
file = open('tag.txt', 'r', encoding='utf-8')
tag = file.read().splitlines()

tags = []
for tagged_token in tag:
    tag = tagged_token.split('\t')[1]
    tags.append(tag)

tag_counts = nltk.Counter(tags)

top5_tags = tag_counts.most_common(5)

for tag, count in top5_tags:
    print(f"{tag}: {count}")

file.close()

# 下载WordNet语料库（如果尚未下载）
nltk.download('wordnet')

# 初始化词形还原器
lemmatizer = WordNetLemmatizer()

# 从tag.txt文件中读取词性数据
file = open('tag.txt', 'r', encoding='utf-8')
tags = [line.strip().split('\t') for line in file]

# 对词汇进行词形还原并存储结果
lemmatized_words = [lemmatizer.lemmatize(token) for token, _ in tags]

# 打印前20个词形还原后的词汇
print("前20个词形还原后的词汇：")
for word in lemmatized_words[:20]:
    print(word)

file.close()

# 下面进行词频统计
file = open('tag.txt', 'r', encoding='utf-8')
tag = file.read().splitlines()

tags = []
for tagged_token in tag:
    tag = tagged_token.split('\t')[1]
    tags.append(tag)

tag_counts = nltk.Counter(tags)

tag_freq = FreqDist(tags)

# 获取词性标记和它们的频率
labels, frequencies = zip(*tag_freq.items())

# 绘制条形图
plt.figure(figsize=(12, 6))
plt.bar(labels, frequencies, color='skyblue')
plt.xlabel('POS Tags')
plt.ylabel('Frequency')
plt.title('POS Tags Frequency Distribution')
plt.xticks(rotation=90)  # 旋转标签以避免重叠

plt.savefig('pos_frequency_chart.png', bbox_inches='tight', dpi=300)

# 显示图表
plt.show()

